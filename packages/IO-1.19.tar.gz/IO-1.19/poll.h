/*
 * poll.h
 *
 * Copyright (c) 1997-8 Graham Barr <gbarr@pobox.com>. All rights reserved.
 * This program is free software; You may modify this code for your own use
 * but may only be re-distributed in an unaltered form and with prior consent
 * of the copyright owner.
 *
 */

#ifndef POLL_H
#  define POLL_H

#if defined(I_POLL) || defined(POLLWRBAND)
#  include <poll.h>
#  ifndef HAS_POLL
#    define HAS_POLL
#  endif
#else
#ifdef HAS_SELECT


/* We shall emulate poll using select */

#define EMULATE_POLL_WITH_SELECT

typedef struct pollfd {
    int fd;
    short events;
    short revents;
} pollfd_t;

#define	POLLIN		0x0001
#define	POLLPRI		0x0002
#define	POLLOUT		0x0004
#define	POLLRDNORM	0x0040
#define	POLLWRNORM	POLLOUT
#define	POLLRDBAND	0x0080
#define	POLLWRBAND	0x0100
#define	POLLNORM	POLLRDNORM

/* Return ONLY events (NON testable) */

#define	POLLERR		0x0008
#define	POLLHUP		0x0010
#define	POLLNVAL	0x0020

int poll _((struct pollfd *, unsigned long, int));

#ifndef HAS_POLL
#  define HAS_POLL
#endif

#endif /* HAS_SELECT */

#endif /* I_POLL */

#endif /* POLL_H */

